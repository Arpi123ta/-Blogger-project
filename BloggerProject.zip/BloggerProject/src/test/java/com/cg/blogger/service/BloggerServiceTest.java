package com.cg.blogger.service;

import java.util.List;

import javax.persistence.EntityManager;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cg.blogger.entity.Blogger;

@ExtendWith({SpringExtension.class})
@DataJpaTest
@Import(BloggerServiceImpl.class)
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class BloggerServiceTest {
	@Autowired
	private BloggerServiceImpl service;
	@Autowired
	private EntityManager em;
	
	@Test
	public void testfindByAll() {
		List<Blogger> blogFound = service.findAll();
		System.out.println(blogFound);
		Assertions.assertTrue(blogFound.equals(blogFound));
		
	}
	
	@Test
	public void  testFindByName() {
		List<Blogger> blogFound =  service.findByBloggerName("Akshay");
		System.out.println(blogFound);
		Assertions.assertTrue(blogFound.size()>0);
		
	}
	
}
