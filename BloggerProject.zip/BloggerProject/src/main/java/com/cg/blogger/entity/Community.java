package com.cg.blogger.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="community")
public class Community {
	@Id
	@GeneratedValue
	private int commid;
	private String commDesc;
	private int members;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="blog_id")
	private Blogger blogger;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="admin_userid")
	private Admin admin;
public Community() {
	
}

public Community(int commid, String commDesc, int members) {
	super();
	this.commid = commid;
	this.commDesc = commDesc;
	this.members = members;
}

@Override
public String toString() {
	return "Community [commid=" + commid + ", commDesc=" + commDesc + ", members=" + members +"]";
}
public int getCommid() {
	return commid;
}
public String getCommDesc() {
	return commDesc;
}
public int getMembers() {
	return members;
}
public Blogger getBlogger() {
	return blogger;
}
public void setCommid(int commid) {
	this.commid = commid;
}
public void setCommDesc(String commDesc) {
	this.commDesc = commDesc;
}
public void setMembers(int members) {
	this.members = members;
}
public void setBlogger(Blogger blogger) {
	this.blogger = blogger;
}
public Admin getAdmin() {
	return admin;
}
public void setAdmin(Admin admin) {
	this.admin = admin;
}


 
}
