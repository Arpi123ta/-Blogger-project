package com.cg.blogger.exception;

public class BloggerNotFoundException extends RuntimeException {
        public BloggerNotFoundException(String msg) {
        	super(msg);
        }
}
