package com.cg.blogger.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import com.cg.blogger.entity.Community;

public class CreateAdminRequest {
	@NotBlank @Size(min=2, max=20)
	private String adminName;
	private long adminContact;
	private List<Community>communities = new ArrayList<>();
	@Override
	public String toString() {
		return "CreateAdminRequest [adminName=" + adminName + ", adminContact=" + adminContact + ", community="
				+ communities + "]";
	}
	public String getAdminName() {
		return adminName;
	}
	public long getAdminContact() {
		return adminContact;
	}
	public List<Community> getCommunities() {
		return communities;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public void setAdminContact(long adminContact) {
		this.adminContact = adminContact;
	}
	public void setCommunity(List<Community> communities) {
		this.communities = communities;
	}
		
			
	

}
