package com.cg.blogger.dto;

public class AdminDetails {
    private Integer userid;
    private String adminName;
    private long adminContact;
	public AdminDetails() {
		
	}
	public AdminDetails(Integer userid,String adminName) {
		this.userid = userid;
		this.adminName = adminName;
		
	}
	public AdminDetails(Integer userid, String adminName, long adminContact) {
		super();
		this.userid = userid;
		this.adminName = adminName;
		this.adminContact = adminContact;
	}
	
	public Integer getUserid() {
		return userid;
	}
	public String getAdminName() {
		return adminName;
	}
	public long getAdminContact() {
		return adminContact;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public void setAdminContact(long adminContact) {
		this.adminContact = adminContact;
	}
    
}
