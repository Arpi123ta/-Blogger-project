package com.cg.blogger.exception;

public class BloggerAlreadyExistsException extends RuntimeException {
       public BloggerAlreadyExistsException (String msg) {
    	   super(msg);
       }
}
