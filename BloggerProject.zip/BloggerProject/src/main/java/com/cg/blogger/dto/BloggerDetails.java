package com.cg.blogger.dto;

import java.util.ArrayList;
import java.util.List;

import com.cg.blogger.entity.Comment;
import com.cg.blogger.entity.Community;
import com.cg.blogger.entity.Post;

public class BloggerDetails {
     private Integer id;
     private String bloggerName;
	 private List<PostDetails> post1;
	 private List<CommentDetails> comment1;
	 private List<CommunityDetails> community1;
		
	public List<PostDetails> getPost1() {
		return post1;
	}
	public void setPost1(List<PostDetails> post1) {
		this.post1 = post1;
	}
	public List<CommentDetails> getComment1() {
		return comment1;
	}
	public void setComment1(List<CommentDetails> comment1) {
		this.comment1 = comment1;
	}
	public List<CommunityDetails> getCommunity1() {
		return community1;
	}
	public void setCommunity1(List<CommunityDetails> community1) {
		this.community1 = community1;
	}
	public BloggerDetails() {
		
	}
	public BloggerDetails(Integer id, String bloggerName,List<PostDetails> post1,List<CommentDetails> comment1,List<CommunityDetails> community1) {
		super();
		this.id = id;
		this.bloggerName = bloggerName;
		this.post1=post1;
		this.comment1=comment1;
		this.community1=community1;
	}
	public BloggerDetails(Integer id, String bloggerName) {
		this.id = id;
		this.bloggerName = bloggerName;
				
	}
	
	public int getUserId() {
		return id;
	}
	public String getBloggerName() {
		return bloggerName;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public void setBloggerName(String bloggerName) {
		this.bloggerName = bloggerName;
	}
	     
}
