package com.cg.blogger.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.cg.blogger.entity.Comment;
import com.cg.blogger.entity.Community;
import com.cg.blogger.entity.Post;

public class CreateBloggerRequest {
	@NotBlank @Size(min=2, max=20)
	private String bloggerName;
	private List<Post> posts = new ArrayList<>();
	private List<Comment>comments = new ArrayList<>();
	private List<Community>communities = new ArrayList<>();
	@Override
	public String toString() {
		return "CreateBloggerRequest [bloggerName=" + bloggerName+ ", posts=" + posts + ", comments=" + comments + ", communities=" + communities + "]";
	}
	public String getBloggerName() {
		return bloggerName;
	}
	public List<Post> getPosts() {
		return posts;
	}
	public void setBloggerName(String bloggerName) {
		this.bloggerName = bloggerName;
	}
	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}
	public List<Comment> getComments() {
		return comments;
	}
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	public List<Community> getCommunities() {
		return communities;
	}
	public void setCommunity(List<Community> communities) {
		this.communities = communities;
	}
	public void setCommunities(List<Community> communities) {
		this.communities = communities;
	}
	
	
}
