package com.cg.blogger.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.cg.blogger.dto.BloggerDetails;
import com.cg.blogger.dto.CommentDetails;
import com.cg.blogger.dto.CommunityDetails;
import com.cg.blogger.dto.PostDetails;
import com.cg.blogger.entity.Blogger;
import com.cg.blogger.entity.Comment;
import com.cg.blogger.entity.Community;
import com.cg.blogger.entity.Post;


@Component
public class BloggerUtil {
	public BloggerDetails toDetails(Blogger blogger) {
		List<Post> posts = blogger.getPosts();
		List<PostDetails> details = new ArrayList<>();
		// to prevent cyclic reference to student in course when json is created
		for (Post post : posts) {
			details.add(new PostDetails(post));
		}
				          
		List<Comment> comments = blogger.getComments();
			List<CommentDetails> detail = new ArrayList<>();
			// to prevent cyclic reference to student in course when json is created
			for (Comment comment : comments) {
				detail.add(new CommentDetails(comment));
			}
			List<Community> communities = blogger.getCommunities();
			List<CommunityDetails> data = new ArrayList<>();
			// to prevent cyclic reference to student in course when json is created
			for (Community community : communities) {
				data.add(new CommunityDetails(community));
			}
			return new BloggerDetails(blogger.getId(), blogger.getBloggerName(),details,detail,data);
	}

       
    
	public List<BloggerDetails> toDetails(Collection<Blogger> bloggers) {
        List<BloggerDetails> detailList = new ArrayList<>();
        for (Blogger blogger : bloggers) {
            BloggerDetails details = toDetails(blogger);
            System.out.println(details);
            detailList.add(details);
        }
        return detailList;
	}
}
