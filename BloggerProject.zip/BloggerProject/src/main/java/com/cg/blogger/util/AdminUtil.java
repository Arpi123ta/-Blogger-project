package com.cg.blogger.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.blogger.dto.AdminDetails;
import com.cg.blogger.dto.BloggerDetails;
import com.cg.blogger.dto.CommunityDetails;
import com.cg.blogger.entity.Admin;
import com.cg.blogger.entity.Blogger;
import com.cg.blogger.entity.Community;
@Component
public class AdminUtil {

	public AdminDetails toDetails(Admin admin) {
		List<Community> communities = admin.getCommunities();
		List<CommunityDetails> data = new ArrayList<>();
		// to prevent cyclic reference to student in course when json is created
		for (Community community : communities) {
			data.add(new CommunityDetails(community));
		}
		return new AdminDetails(admin.getUserid(), admin.getAdminName(),admin.getAdminContact());
	}
	public List<AdminDetails> toDetails(Collection<Admin> admins) {
        List<AdminDetails> detailList = new ArrayList<>();
        for (Admin admin : admins) {
            AdminDetails details = toDetails(admin);
            System.out.println(details);
            detailList.add(details);
        }
        return detailList;
	}

}
