package com.cg.blogger.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.blogger.dto.UserDetails;
import com.cg.blogger.dao.IBloggerDao;
import com.cg.blogger.entity.Blogger;
import com.cg.blogger.entity.Post;
import com.cg.blogger.exception.AuthenticationFailedException;
import com.cg.blogger.exception.BloggerAlreadyExistsException;
import com.cg.blogger.exception.BloggerNotExistsException;
import com.cg.blogger.exception.BloggerNotFoundException;

@Service
@Transactional
public class BloggerServiceImpl implements IBloggerService {
	@Autowired
	private IBloggerDao bDao;
	

	@Override
	public List<Blogger> findByBloggerName(String bloggerName) {
		System.out.println("name: " + bloggerName);
		List<Blogger> list = bDao.findByBloggerName(bloggerName);
		return list;
	}
	@Override
	public Blogger findById(Integer id) {
		System.out.println("id: "+id);
        Optional<Blogger> optional = bDao.findById(id);
        if(!optional.isPresent()){
        	System.out.println("***error***");
            throw new BloggerNotFoundException("blogger not found for id="+id);
        }
        Blogger blogger=optional.get();
        System.out.println("blog: "+ blogger);
        return blogger;
	}
	@Override
	public Blogger register(Blogger blogger) {
		boolean exists=blogger.getId()!=null && bDao.existsById(blogger.getId());
		if(exists){
			throw new BloggerAlreadyExistsException("Blogger already exists for id="+blogger.getId());
			}
			blogger = bDao.save(blogger);
			System.out.println("returning saved blogger: " + blogger);
			return blogger;
			}

	
	
	@Override
	public List<Blogger> findAll() {
		System.out.println(bDao.getClass().getName());
		List<Blogger> list = bDao.findAll();
        return list;
	}
		
	@Override
	public Blogger deleteBlogger(Integer id) {
		Blogger blogger=findById(id);
		bDao.deleteById(id);
		
		return blogger;
	}
	@Override
	public Blogger updateBlogger(Integer userId) {
		System.out.println("id :" +userId);
		
		 Optional<Blogger> optional = bDao.findById(userId);
	        if(!optional.isPresent()){
	        	System.out.println("***error***");
	            throw new BloggerNotExistsException("blogger not exist for id="+ userId);
	        }
	    Blogger blogger=optional.get();
		blogger=bDao.save(blogger);
		return blogger;	
	}
	
	

}
