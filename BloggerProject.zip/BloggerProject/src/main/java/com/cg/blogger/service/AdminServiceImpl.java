package com.cg.blogger.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.blogger.dao.IAdminDao;
import com.cg.blogger.entity.Admin;
import com.cg.blogger.entity.Blogger;
import com.cg.blogger.exception.AdminAlreadyExistsException;
import com.cg.blogger.exception.AdminNotFoundException;
import com.cg.blogger.exception.BloggerNotExistsException;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {
	@Autowired
	private IAdminDao aDao;
	
	@Override
	public List<Admin> findByAdminName(String adminName) {
		System.out.println("name: " + adminName);
		List<Admin> list = aDao.findByAdminName(adminName);
		return list;
	}
	@Override
	public Admin findByUserId(Integer userid) {
		System.out.println("id: "+userid);
        Optional<Admin> optional = aDao.findByUserid(userid);
        if(!optional.isPresent()){
        	System.out.println("***error***");
            throw new AdminNotFoundException("admin not found for id="+userid);
        }
        Admin admin=optional.get();
        System.out.println("admin: "+ admin);
        return admin;
	}
		
	@Override
	public Admin register(Admin admin) {
		boolean exists=admin.getUserid()!=null && aDao.existsById(admin.getUserid());
		if(exists){
			throw new AdminAlreadyExistsException("Admin already exists for id="+admin.getUserid());
			}
			admin = aDao.save(admin);
			System.out.println("returning saved admin: " + admin);
			return admin;
			}
	
	@Override
	public Admin deleteAdmin(Integer id) {
		Admin admin=findByUserId(id);
		aDao.deleteById(id);
		
		return admin;
	}
	@Override
	public Admin updateAdmin(Integer userId) {
		System.out.println("id :" +userId);
		
		 Optional<Admin> optional = aDao.findByUserid(userId);
	        if(!optional.isPresent()){
	        	System.out.println("***error***");
	            throw new BloggerNotExistsException("blogger not exist for id="+ userId);
	        }
	    Admin admin=optional.get();
		admin=aDao.save(admin);
		return admin;	
	}
	

}

	
	

