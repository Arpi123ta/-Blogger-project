package com.cg.blogger.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="blog")
@NamedQuery(name="Blogger.findBybloggerName",
      query="SELECT blog FROM Blogger blog WHERE blog.bloggerName = ?1 ")

public class Blogger {
	@Id
	@GeneratedValue
     private Integer id;
	@Column(name="bloggerName")
     private String bloggerName;
	@OneToMany(mappedBy="blogger",cascade=CascadeType.ALL)
	private List<Post> posts = new ArrayList<>();
	@OneToMany(mappedBy="blogger",cascade=CascadeType.ALL)
	private List<Comment>comments=new ArrayList<>();
	@OneToMany(mappedBy="blogger",cascade=CascadeType.ALL)
	private List<Community>communities=new ArrayList<>();
	
	public Blogger() {
		
	}
	public Blogger(Integer id, String bloggerName) {
		super();
		this.id = id;
		this.bloggerName = bloggerName;
	}
	public Blogger(String bloggerName) {
		this.bloggerName=bloggerName;
	}
	public void addPost(Post post) {
		post.setBlogger(this);
		posts.add(post);
	}
	public void addComment(Comment comment) {
		comment.setBlogger(this);
		comments.add(comment);
	}
	public void addCommunity(Community community) {
		community.setBlogger(this);
		communities.add(community);
	}
	@Override
	public String toString() {
		return "Blogger [id="+id+ ", bloggerName=" + bloggerName + ", posts=" + posts + ",comments="+comments+",communities="+communities+"]";
	}
	
	public List<Community> getCommunities() {
		return communities;
	}
	public void setCommunities(List<Community> communities) {
		this.communities = communities;
	}
	public List<Post> getPosts() {
		return posts;
	}
	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}
	public Integer getId() {
		return id;
	}
	public String getBloggerName() {
		return bloggerName;
	}
	public void setid(Integer id ) {
		this.id= id;
	}
	public void setBloggerName(String bloggerName) {
		this.bloggerName = bloggerName;
	}
	public List<Comment> getComments() {
		return comments;
	}
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	
	
}
