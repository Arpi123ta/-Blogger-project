package com.cg.blogger.exception;

public class AdminAlreadyExistsException extends RuntimeException {
   public AdminAlreadyExistsException(String msg) {
	     super(msg);
   }
}
