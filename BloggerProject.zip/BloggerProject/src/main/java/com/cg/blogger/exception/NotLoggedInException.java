package com.cg.blogger.exception;

public class NotLoggedInException extends RuntimeException {
     public NotLoggedInException (String msg) {
    	 super(msg);
     }
}
