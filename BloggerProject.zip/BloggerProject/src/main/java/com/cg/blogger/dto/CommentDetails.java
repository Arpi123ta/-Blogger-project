package com.cg.blogger.dto;

import com.cg.blogger.entity.Comment;

public class CommentDetails {
     private int comid;
     private String comDesc;
     private int votes;

	public CommentDetails() {
		super();


	}
	public CommentDetails(Comment comment) {
		comid=comment.getComid();
		comDesc = comment.getComDesc();
		votes=comment.getVotes();
		
	}
	
	public CommentDetails(int comid, String comDesc, int votes) {
		super();
		this.comid = comid;
		this.comDesc = comDesc;
		this.votes = votes;
	}
	public int getComid() {
		return comid;
	}
	public String getComDesc() {
		return comDesc;
	}
	public int getVotes() {
		return votes;
	}
	public void setComid(int comid) {
		this.comid = comid;
	}
	public void setComDesc(String comDesc) {
		this.comDesc = comDesc;
	}
	public void setVotes(int votes) {
		this.votes = votes;
	}
	
     
}
