package com.cg.blogger.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.blogger.dao.UserDao;
import com.cg.blogger.dto.UserDetails;
import com.cg.blogger.exception.AuthenticationFailedException;

@Service
@Transactional
public class UserServiceImpl implements UserServiceIntf 
{
	@Autowired
	private UserDao udao;

	@Override
	public String login(UserDetails userDetails) {
		String role = "";
		Optional<UserDetails> op = udao.findByUsername(userDetails.getUsername());
        if(!op.isPresent()){
            throw new AuthenticationFailedException("No User found for username="+userDetails.getUsername());
        }
		UserDetails uDetails = op.get();
		if(!userDetails.getPassword().equals(uDetails.getPassword())) {
            throw new AuthenticationFailedException("Authentification failed for username="+userDetails.getUsername());
		}
		role = uDetails.getUserRole();
		return role;
	}

	
}
