package com.cg.blogger.dto;

import java.io.File;
import java.time.LocalDate;

import com.cg.blogger.entity.Comment;
import com.cg.blogger.entity.Community;

public class CommunityDetails {
 
	private int commid;
	private String commDesc;
	private int members;
	public CommunityDetails() {
		
	}
	public CommunityDetails(Community community) {
		commid=community.getCommid();
		commDesc = community.getCommDesc();
		members=community.getMembers();
		
	}
	
	public CommunityDetails(int commid, String commDesc, int members) {
		super();
		this.commid = commid;
		this.commDesc = commDesc;
		this.members = members;
			}
	public int getCommid() {
		return commid;
	}
	public String getCommDesc() {
		return commDesc;
	}
	public int getMembers() {
		return members;
	}
	public void setCommid(int commid) {
		this.commid = commid;
	}
	public void setCommDesc(String commDesc) {
		this.commDesc = commDesc;
	}
	public void setMembers(int members) {
		this.members = members;
	}
		
	
}
