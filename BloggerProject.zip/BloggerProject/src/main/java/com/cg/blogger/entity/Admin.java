package com.cg.blogger.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="admin")
@NamedQuery(name="Admin.findByadminName",
      query="SELECT admin FROM  Admin admin WHERE admin.adminName = ?1 ")

public class Admin {
	@Id
	@GeneratedValue
      private Integer userid;
	@Column(name="adminName")
      private String adminName;
	@Column(name="adminContact")
      private long adminContact;
	@OneToMany(mappedBy="admin",cascade=CascadeType.ALL)
	private List<Community>communities=new ArrayList<>();
	public Admin() {
		
	}
	public Admin(Integer userid, String adminName, long adminContact) {
		super();
		this.userid = userid;
		this.adminName = adminName;
		this.adminContact = adminContact;
	}
	public Admin(Admin admin) {
		this.userid = admin.getUserid();
		this.adminName = admin.getAdminName();
		this.adminContact = admin.getAdminContact();
	}

	public Admin(String adminName) {
		this.adminName=adminName;
	}
	public Admin(String adminName, long adminContact) {
		this.adminName = adminName;
		this.adminContact = adminContact;
	}
	public void addCommunity(Community community) {
		community.setAdmin(this);
		communities.add(community);
	}
	@Override
	public String toString() {
		return "Admin [userid=" + userid + ", adminName=" + adminName + ", adminContact=" + adminContact + ",communities="+communities+"]";
	}
	public Integer getUserid() {
		return userid;
	}
	public String getAdminName() {
		return adminName;
	}
	public long getAdminContact() {
		return adminContact;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public void setAdminContact(long adminContact) {
		this.adminContact = adminContact;
	}
	public List<Community> getCommunities() {
		return communities;
	}
	public void setCommunities(List<Community> communities) {
		this.communities = communities;
	}
	
      
}
