package com.cg.blogger.service;

import com.cg.blogger.dto.UserDetails;

public interface UserServiceIntf {


	String login(UserDetails userDetails);


}
