package com.cg.blogger.controller;

import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.blogger.dto.AdminDetails;
import com.cg.blogger.dto.BloggerDetails;
import com.cg.blogger.dto.CreateAdminRequest;
import com.cg.blogger.dto.CreateBloggerRequest;
import com.cg.blogger.dto.UserDetails;
import com.cg.blogger.entity.Admin;
import com.cg.blogger.entity.Blogger;
import com.cg.blogger.entity.Community;
import com.cg.blogger.service.IAdminService;
import com.cg.blogger.service.IBloggerService;
import com.cg.blogger.util.AdminUtil;
import com.cg.blogger.util.BloggerUtil;

@RestController
@RequestMapping("/admin")
@Validated//this is for validating data of the entity
public class AdminController {
	@Autowired
    private IAdminService aservice;
   @Autowired
	private AdminUtil adminUtil;
   
   @GetMapping("/by/name/{name}")
	public List<AdminDetails> fetchAdminByAdminName(@PathVariable("name") String adminName,HttpServletRequest request) {
		System.out.println("cntrlr fetch name: " + adminName);
		List<Admin> admins = aservice.findByAdminName(adminName);
		List<AdminDetails> response = adminUtil.toDetails(admins);
		System.out.println("by name details: " + response);
		return response;
	}
   @GetMapping("/by/id/{id}")
	public AdminDetails fetchAdmin(@PathVariable("id") Integer userid,HttpServletRequest request) {
		System.out.println("cntrlr fetch id: " + userid);
		Admin admin= aservice.findByUserId(userid);
		AdminDetails details = adminUtil.toDetails(admin);
		System.out.println("details: " + details);
		return details;
	}

   
   @ResponseStatus(HttpStatus.CREATED)
	@PostMapping("/createCommunity")
	public AdminDetails add(@RequestBody @Valid CreateAdminRequest requestData) {
		System.out.println("req data: " + requestData);
		Admin admin = new Admin(requestData.getAdminName(),requestData.getAdminContact());
		List<Community> communitySet = requestData.getCommunities();
		if(communitySet!=null) {
			for(Community community : communitySet ) {
				admin.addCommunity(community);
			}
		}
		System.out.println("admin came: " + admin);
		admin = aservice.register(admin);
		AdminDetails details = adminUtil.toDetails(admin);
		return details;
	}
	
   @ResponseStatus(HttpStatus.OK)
	@DeleteMapping("/delete/id/{id}")
	public AdminDetails deleteAdmin(@PathVariable("id") Integer id)
	{
		Admin removeAdmin = aservice.deleteAdmin(id);
		AdminDetails response =  adminUtil.toDetails(removeAdmin);
		return response;
	}
	
   @ResponseStatus(HttpStatus.OK)
	@PutMapping("/update/id/{id}")
	public AdminDetails updateAdmin(@PathVariable("id") Integer userId)
	{
		System.out.println("cntrlr fetched id:" +userId);
		Admin admin=aservice.updateAdmin(userId);
		AdminDetails details = adminUtil.toDetails(admin);
		System.out.println("details: " + details);
		return details;
	}


      

}
