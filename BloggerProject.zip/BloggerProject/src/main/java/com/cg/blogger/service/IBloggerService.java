package com.cg.blogger.service;

import java.util.List;

import com.cg.blogger.dto.UserDetails;
import com.cg.blogger.entity.Blogger;
import com.cg.blogger.entity.Post;

public interface IBloggerService {

	

	Blogger findById(Integer id);

	//Blogger register(Blogger blogger);

	List<Blogger> findAll();


	List<Blogger> findByBloggerName(String bloggerName);

	Blogger register(Blogger blogger);

	Blogger deleteBlogger(Integer id);

	Blogger updateBlogger(Integer userId);

	

	

}
