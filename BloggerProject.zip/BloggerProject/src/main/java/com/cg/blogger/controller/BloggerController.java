package com.cg.blogger.controller;

import java.util.Enumeration;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.blogger.dto.BloggerDetails;
import com.cg.blogger.dto.CreateBloggerRequest;
import com.cg.blogger.dto.PostDetails;
import com.cg.blogger.dto.UserDetails;
import com.cg.blogger.entity.Admin;
import com.cg.blogger.entity.Blogger;
import com.cg.blogger.entity.Comment;
import com.cg.blogger.entity.Community;
import com.cg.blogger.entity.Post;
import com.cg.blogger.exception.NotLoggedInException;
import com.cg.blogger.service.IBloggerService;
import com.cg.blogger.util.BloggerUtil;

@RestController
@RequestMapping("/bloggers")
@Validated//this is for validating data of the entity
public class BloggerController {
	     @Autowired
         private IBloggerService service;
	    @Autowired
		private BloggerUtil bloggerUtil;
	    
	    @GetMapping("/by/name/{name}")
		public List<BloggerDetails> fetchBloggerByBloggerName(@PathVariable("name") String bloggerName,HttpServletRequest request) {
			System.out.println("cntrlr fetch name: " + bloggerName);
			List<Blogger> bloggers = service.findByBloggerName(bloggerName);
			List<BloggerDetails> response = bloggerUtil.toDetails(bloggers);
			System.out.println("by name details: " + response);
			return response;
		}
	    @GetMapping("/by/id/{id}")
		public BloggerDetails fetchBlogger(@PathVariable("id") Integer id,HttpServletRequest request) {
			System.out.println("cntrlr fetch id: " + id);
			Blogger blogger= service.findById(id);
			BloggerDetails details = bloggerUtil.toDetails(blogger);
			System.out.println("details: " + details);
			return details;
		}

		@GetMapping("/bloggers")
		public List<BloggerDetails> fetchAll(HttpServletRequest request) {
			String userName = (String) request.getSession().getAttribute("user");
			System.out.println(userName);
			if(userName==null) {
				throw new NotLoggedInException("You have not logged in");
			}
			List<Blogger> bloggers = service.findAll();
			List<BloggerDetails> response = bloggerUtil.toDetails(bloggers);
			return response;
		}
		@ResponseStatus(HttpStatus.CREATED)
		@PostMapping("/add")
		public BloggerDetails add(@RequestBody @Valid CreateBloggerRequest requestData) {
			System.out.println("req data: " + requestData);
			Blogger blogger = new Blogger(requestData.getBloggerName());
			List<Post> postsSet = requestData.getPosts();
			if ( postsSet!= null) {
				for (Post post : postsSet) {
					blogger.addPost(post);
				}
			}
			List<Comment> commentsSet = requestData.getComments();
			if(commentsSet!=null) {
				for(Comment comment : commentsSet ) {
					blogger.addComment(comment);
				}
			}
			List<Community> communitySet = requestData.getCommunities();
			if(communitySet!=null) {
				for(Community community : communitySet ) {
					blogger.addCommunity(community);
				}
			}
			System.out.println("blog came: " + blogger);
			blogger = service.register(blogger);
			BloggerDetails details = bloggerUtil.toDetails(blogger);
			return details;
		}
		
				
		@ResponseStatus(HttpStatus.OK)
		@DeleteMapping("/delete/id/{id}")
		public BloggerDetails deleteBlogger(@PathVariable("id") Integer id)
		{
			Blogger removeBlogi = service.deleteBlogger(id);
			BloggerDetails response =  bloggerUtil.toDetails(removeBlogi);
			return response;
		}
		
		@ResponseStatus(HttpStatus.OK)
		@PutMapping("/update/id/{id}")
		public BloggerDetails updateBlogger(@PathVariable("id") Integer userId)
		{
			System.out.println("cntrlr fetched id:" +userId);
			Blogger blogger=service.updateBlogger(userId);
			BloggerDetails details = bloggerUtil.toDetails(blogger);
			System.out.println("details: " + details);
			return details;
		}

}
