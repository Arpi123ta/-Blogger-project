package com.cg.blogger.service;

import java.util.List;

import com.cg.blogger.dto.UserDetails;
import com.cg.blogger.entity.Admin;

public interface IAdminService {


	Admin register(Admin admin);

	List<Admin> findByAdminName(String adminName);

	Admin findByUserId(Integer userid);

	Admin deleteAdmin(Integer id);

	Admin updateAdmin(Integer userId);

}
