package com.cg.blogger.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.blogger.entity.Blogger;
import com.cg.blogger.entity.Post;


public interface IBloggerDao extends JpaRepository<Blogger, Integer>{

	List<Blogger> findByBloggerName(String bloggerName);


	

	

}
