package com.cg.blogger.exception;

public class AuthenticationFailedException extends RuntimeException {
        public  AuthenticationFailedException (String msg) {
        	super(msg);
        }
}
