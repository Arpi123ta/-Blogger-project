package com.cg.blogger.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="blog_post")
public class Post {
	@Id
	@GeneratedValue
	private int id;
	private String title;
	private Integer votes;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="blog_id")
	private Blogger blogger;
	
	
	public Post() {
		
	}

	public Post(int id, String title, Integer votes) {
		super();
		this.id = id;
		this.title = title;
		this.votes = votes;
	}

	@Override
	public String toString() {
		return "Post [id=" + id + ", title=" + title + ", votes=" + votes + "]";
	}

	public Integer getVotes() {
		return votes;
	}

	public void setVotes(Integer votes) {
		this.votes = votes;
	}

	public int getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public Blogger getBlogger() {
		return blogger;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setBlogger(Blogger blogger) {
		this.blogger = blogger;
	}

		
}
