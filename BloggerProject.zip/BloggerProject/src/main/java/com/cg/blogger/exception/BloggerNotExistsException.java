package com.cg.blogger.exception;

public class BloggerNotExistsException extends RuntimeException {

	public BloggerNotExistsException(String msg) {
		super(msg);
	}

}
