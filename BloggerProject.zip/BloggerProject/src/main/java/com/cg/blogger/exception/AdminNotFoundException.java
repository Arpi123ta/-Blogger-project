package com.cg.blogger.exception;

public class AdminNotFoundException extends RuntimeException{
	public AdminNotFoundException(String msg) {
		super(msg);
	}
}
