package com.cg.blogger.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.blogger.entity.Admin;
import com.cg.blogger.entity.Blogger;

public interface IAdminDao extends JpaRepository<Admin, Integer>{

	List<Admin> findByAdminName(String adminName);

	Optional<Admin> findByUserid(Integer userid);



	

}
