package com.cg.blogger.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="comment")
public class Comment {
	@Id
	@GeneratedValue
     private int comid;
     private String comDesc;
     private int votes;
     @ManyToOne(cascade=CascadeType.ALL)
 	 @JoinColumn(name="blog_id")
 	 private Blogger blogger;
     
     
	public Comment() {
		
	}
	public Comment(int comid, String comDesc, int votes, Blogger blogger) {
		super();
		this.comid = comid;
		this.comDesc = comDesc;
		this.votes = votes;
		this.blogger = blogger;
	}
	@Override
	public String toString() {
		return "Comment [comid=" + comid + ", comDesc=" + comDesc + ", votes=" + votes+ "]";
	}
	public int getComid() {
		return comid;
	}
	public String getComDesc() {
		return comDesc;
	}
	public int getVotes() {
		return votes;
	}
	public Blogger getBlogger() {
		return blogger;
	}
	public void setComid(int comid) {
		this.comid = comid;
	}
	public void setComDesc(String comDesc) {
		this.comDesc = comDesc;
	}
	public void setVotes(int votes) {
		this.votes = votes;
	}
	public void setBlogger(Blogger blogger) {
		this.blogger = blogger;
	}
	     
}
