package com.cg.blogger.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.cg.blogger.entity.Post;

public class PostDetails {
   private int id;
   private String title;
   private Integer votes;
public PostDetails() {
	super();
}
public PostDetails(Post post) {
	id = post.getId();
	title = post.getTitle();
	votes=post.getVotes();
}
public PostDetails(int id, String title, Integer votes) {
	super();
	this.id = id;
	this.title = title;
	this.votes = votes;
}
public Integer getVotes() {
	return votes;
}
public void setVotes(Integer votes) {
	this.votes = votes;
}
public int getId() {
	return id;
}
public String getTitle() {
	return title;
}
public void setId(int id) {
	this.id = id;
}
public void setTitle(String title) {
	this.title = title;
}

}
