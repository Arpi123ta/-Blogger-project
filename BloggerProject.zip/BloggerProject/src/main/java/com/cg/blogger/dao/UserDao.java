package com.cg.blogger.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.blogger.dto.UserDetails;

public interface UserDao extends JpaRepository<UserDetails, Integer>{


	Optional<UserDetails> findByUsername(String username);



}
